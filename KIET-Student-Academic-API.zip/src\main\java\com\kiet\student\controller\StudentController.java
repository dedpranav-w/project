package com.kiet.student.controller;

import com.kiet.student.model.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
public class StudentController {
    private final List<Student> students = new CopyOnWriteArrayList<>(List.of(
            new Student(101, "Rahul Sharma", "rahul@kiet.edu", "CSE", 2, 8.65),
            new Student(102, "Priya Singh", "priya@kiet.edu", "ECE", 3, 9.10),
            new Student(103, "Arjun Verma", "arjun@kiet.edu", "CSE", 2, 8.20),
            new Student(104, "Neha Gupta", "neha@kiet.edu", "IT", 4, 9.25),
            new Student(105, "Karan Patel", "karan@kiet.edu", "ME", 1, 7.90)
    ));

    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return students;
    }

    @GetMapping("/students/{studentId}")
    public ResponseEntity<?> getStudentById(@PathVariable int studentId) {
        return students.stream()
                .filter(student -> student.getStudentId() == studentId)
                .findFirst()
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> notFound());
    }

    @PostMapping("/students")
    public ResponseEntity<?> addStudent(@RequestBody Student student) {
        if (students.stream().anyMatch(existing -> existing.getStudentId() == student.getStudentId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Student ID already exists"));
        }
        students.add(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(student);
    }

    @PutMapping("/students/{studentId}")
    public ResponseEntity<?> updateStudent(@PathVariable int studentId, @RequestBody Student updatedStudent) {
        for (int index = 0; index < students.size(); index++) {
            if (students.get(index).getStudentId() == studentId) {
                updatedStudent.setStudentId(studentId);
                students.set(index, updatedStudent);
                return ResponseEntity.ok(updatedStudent);
            }
        }
        return notFound();
    }

    @DeleteMapping("/students/{studentId}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable int studentId) {
        boolean removed = students.removeIf(student -> student.getStudentId() == studentId);
        if (!removed) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Student not found"));
        }
        return ResponseEntity.ok(Map.of("message", "Student deleted successfully"));
    }

    @GetMapping("/students/search")
    public List<Student> searchStudents(@RequestParam String branch, @RequestParam int year) {
        return students.stream()
                .filter(student -> student.getBranch().equalsIgnoreCase(branch)
                        && student.getYear() == year)
                .toList();
    }

    @GetMapping("/students/topper")
    public List<Student> getStudentsByMinimumCgpa(@RequestParam double cgpa) {
        return students.stream()
                .filter(student -> student.getCgpa() >= cgpa)
                .toList();
    }

    private ResponseEntity<Map<String, String>> notFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Student not found"));
    }
}
