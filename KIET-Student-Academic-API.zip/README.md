# KIET Student Academic Management REST API

A Java 17 / Spring Boot REST API implementing the case study. Student records are stored in an in-memory list and reset whenever the application restarts. The assignment explicitly requires no database, so MySQL Connector is intentionally not included.

## Requirements
- JDK 17 or newer
- IntelliJ IDEA (Maven support)
- Internet access on first Maven import so Maven can download Spring Boot dependencies
- Postman (optional; a ready-to-import collection is in `postman/`)

## Open and run in IntelliJ
1. Extract this ZIP.
2. In IntelliJ, choose **File → Open** and select the extracted `student-academic-api` folder (the folder containing `pom.xml`).
3. Accept the Maven project import and wait for dependencies to finish downloading.
4. Set the project SDK to JDK 17: **File → Project Structure → Project SDK**.
5. Open `StudentApplication.java` and click the green run icon beside `main`, or run `StudentApplication` from IntelliJ.
6. Confirm the console prints the three startup messages. The API listens on `http://localhost:8080`.

## Postman
Import `postman/KIET-Student-Academic-API.postman_collection.json`. Requests use `http://localhost:8080` and can be run after starting the app. The collection includes list/get/add/update/delete, branch/year search, CGPA filter, and not-found examples. POST creates student 106; the collection's DELETE example removes student 105.

## Endpoints
| Method | Path | Description |
|---|---|---|
| GET | `/students` | List all students |
| GET | `/students/{studentId}` | Find a student (404 JSON message if absent) |
| POST | `/students` | Add a student using a JSON body (409 if ID exists) |
| PUT | `/students/{studentId}` | Replace a student's details |
| DELETE | `/students/{studentId}` | Delete a student |
| GET | `/students/search?branch=CSE&year=2` | Match branch (case-insensitive) and year |
| GET | `/students/topper?cgpa=9.0` | Students with CGPA at least the supplied value |

### Example POST body
```json
{
  "studentId": 106,
  "name": "Amit Kumar",
  "email": "amit@kiet.edu",
  "branch": "CSE(AI)",
  "year": 2,
  "cgpa": 8.75
}
```

## Claude Code prompt
See `CLAUDE_CODE_PROMPT.md` for a ready-to-paste prompt that asks Claude Code to inspect this project, preserve the assignment requirements, and check its implementation.
