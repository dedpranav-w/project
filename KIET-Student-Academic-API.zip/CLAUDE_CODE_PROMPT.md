You are working on the KIET Student Academic Management REST API assignment in this repository. First inspect the existing files and assignment requirements before editing anything.

Required stack and constraints:
- Java 17, Spring Boot, Maven, IntelliJ IDEA, and Postman.
- Implement the API exactly as an in-memory `List<Student>` application. The case study explicitly says no database is required. Do not add MySQL Connector, JDBC, JPA, database configuration, or external persistence.
- Package root: `com.kiet.student`; main class `StudentApplication`; model `Student`; controller `StudentController`.
- Server port 8080 and Spring Web dependency.
- On startup, use a Spring Boot logger via `CommandLineRunner` to emit exactly these messages: `KIET Student Management System Started`, `Loading Student Data...`, `Student Management REST API is Ready`.
- Seed at least five students.
- Implement GET `/students`, GET `/students/{studentId}` using `@PathVariable`, POST `/students` using `@RequestBody`, PUT `/students/{studentId}` using `@PathVariable` and `@RequestBody`, DELETE `/students/{studentId}`, GET `/students/search?branch=CSE&year=2` using `@RequestParam`, and GET `/students/topper?cgpa=9.0` using `@RequestParam` and a greater-than-or-equal comparison.
- Missing IDs must return HTTP 404 with JSON `{"message":"Student not found"}`. Successful deletion returns `{"message":"Student deleted successfully"}`.

Work carefully: inspect `pom.xml`, Java sources, app properties, README, and Postman collection. Fix actual defects, keep the code simple and beginner-friendly, and ensure the Postman examples match the API. Do not claim anything was compiled or tested unless you actually ran it. If Maven/JDK are unavailable, state that clearly and provide the IntelliJ steps needed to run it. Finish by summarizing changed files and exact run/import steps.
